#ifndef __WAKEUP_H
#define __WAKEUP_H

#include "stm32f4xx.h"




void Wakeup_Init(void);

void Enter_Standby(void);



#endif