#ifndef __RTC_H
#define __RTC_H
#include "stm32f4xx.h"


extern uint8_t RTC_Year;
extern uint8_t RTC_Month;
extern uint8_t RTC_Date;
extern uint8_t RTC_WeekDay;
extern uint8_t RTC_Hours;
extern uint8_t RTC_Minutes;
extern uint8_t RTC_Seconds;

void Rtc_Init(void);



#endif