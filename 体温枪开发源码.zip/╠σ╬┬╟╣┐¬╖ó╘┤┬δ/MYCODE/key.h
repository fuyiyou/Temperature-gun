#ifndef __KEY_H
#define __KEY_H

#include "stm32f4xx.h"

//��ʼ��KEY
void key_Init(void);



#endif