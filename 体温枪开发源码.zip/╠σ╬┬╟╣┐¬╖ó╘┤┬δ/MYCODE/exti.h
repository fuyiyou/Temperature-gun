#ifndef __EXTI_H
#define __EXTI_H

#include "stm32f4xx.h"




void Exti_PA0_Init(void);




#endif

