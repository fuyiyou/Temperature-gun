#ifndef __TIME_H
#define __TIME_H

#include "stm32f4xx.h"

extern RTC_TimeTypeDef RTC_TimeStruct;
extern RTC_DateTypeDef RTC_DateStruct;
extern	float RH_data;
extern	float TH_data;
void Tim3_Init(void);

void Tim4_Init(void);

#endif